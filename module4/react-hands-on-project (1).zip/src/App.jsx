import { useState } from 'react';
import StudentProfile from './components/StudentProfile';
import StudentMarks from './components/StudentMarks';
import LoginForm from './components/LoginForm';

function App() {
  const [activePage, setActivePage] = useState('profile');

  return (
    <div className="app">
      <header className="header">
        <div>
          <p className="eyebrow">React Hands-On</p>
          <h1>Student Management App</h1>
          <p className="subtitle">Props + State + Form Handling</p>
        </div>
      </header>

      <nav className="nav">
        <button
          className={activePage === 'profile' ? 'active' : ''}
          onClick={() => setActivePage('profile')}
        >
          Hands-On 1
        </button>
        <button
          className={activePage === 'marks' ? 'active' : ''}
          onClick={() => setActivePage('marks')}
        >
          Hands-On 2
        </button>
        <button
          className={activePage === 'login' ? 'active' : ''}
          onClick={() => setActivePage('login')}
        >
          Hands-On 3
        </button>
      </nav>

      <main className="content">
        {activePage === 'profile' && (
          <section>
            <div className="section-heading">
              <span>01</span>
              <div>
                <h2>Student Profile Using Props</h2>
                <p>Reusable component receiving student details through props.</p>
              </div>
            </div>
            <StudentProfile
              name="Rahul"
              rollNo="101"
              course="BCA"
              college="ABC College"
            />
          </section>
        )}

        {activePage === 'marks' && (
          <section>
            <div className="section-heading">
              <span>02</span>
              <div>
                <h2>Student Marks Using Props + State</h2>
                <p>Name and subject come through props. Marks are managed with state.</p>
              </div>
            </div>
            <StudentMarks name="Rahul" subject="Java" />
          </section>
        )}

        {activePage === 'login' && (
          <section>
            <div className="section-heading">
              <span>03</span>
              <div>
                <h2>Login Form Using State</h2>
                <p>Username and password are stored and checked using React state.</p>
              </div>
            </div>
            <LoginForm />
          </section>
        )}
      </main>

      <footer>
        React Hands-On Project • Props and State
      </footer>
    </div>
  );
}

export default App;