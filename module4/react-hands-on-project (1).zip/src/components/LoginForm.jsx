import { useState } from 'react';

function LoginForm() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleLogin = (event) => {
    event.preventDefault();

    if (username.trim() && password.trim()) {
      setMessage('Login Successful');
    } else {
      setMessage('Please enter username and password');
    }
  };

  return (
    <div className="card login-card">
      <div className="card-icon">🔐</div>
      <h3>Login</h3>

      <form onSubmit={handleLogin}>
        <label htmlFor="username">Username</label>
        <input
          id="username"
          type="text"
          value={username}
          onChange={(event) => setUsername(event.target.value)}
          placeholder="Enter username"
        />

        <label htmlFor="password">Password</label>
        <input
          id="password"
          type="password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          placeholder="Enter password"
        />

        <button className="login-btn" type="submit">
          Login
        </button>
      </form>

      {message && (
        <p className={message === 'Login Successful' ? 'success' : 'error'}>
          {message}
        </p>
      )}
    </div>
  );
}

export default LoginForm;