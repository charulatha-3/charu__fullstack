function StudentProfile({ name, rollNo, course, college }) {
  return (
    <div className="card profile-card">
      <div className="card-icon">🎓</div>
      <h3>Student Profile</h3>
      <div className="profile-list">
        <div><span>Name</span><strong>{name}</strong></div>
        <div><span>Roll No</span><strong>{rollNo}</strong></div>
        <div><span>Course</span><strong>{course}</strong></div>
        <div><span>College</span><strong>{college}</strong></div>
      </div>
    </div>
  );
}

export default StudentProfile;