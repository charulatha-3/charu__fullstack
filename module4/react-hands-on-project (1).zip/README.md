# React Hands-On Project

A simple React project implementing the three hands-on exercises from the assignment.

## Hands-On 1: Student Profile Using Props

Reusable `StudentProfile` component receives:

- name
- rollNo
- course
- college

The values are passed from `App.jsx` using props.

## Hands-On 2: Student Marks Using Props + State

`StudentMarks` receives:

- name
- subject

through props.

The marks are stored using `useState()`. The Increase Marks and Decrease Marks buttons update the state.

## Hands-On 3: Login Form Using State

`LoginForm` stores username and password using `useState()`.

When Login is clicked:

- If both fields contain values: `Login Successful`
- If either field is empty: `Please enter username and password`

## Run in VS Code

1. Install Node.js.
2. Open this project folder in VS Code.
3. Open the VS Code terminal.
4. Run:

```bash
npm install
npm run dev
```

5. Open the local URL shown by Vite, usually:

```text
http://localhost:5173
```

## Build

```bash
npm run build
```

## Push to GitHub

Create a new empty repository on GitHub, then run these commands in the VS Code terminal:

```bash
git init
git add .
git commit -m "Create React hands-on project"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Replace `YOUR_GITHUB_REPOSITORY_URL` with your own GitHub repository URL.

## Project Structure

```text
react-hands-on-project/
├── src/
│   ├── components/
│   │   ├── StudentProfile.jsx
│   │   ├── StudentMarks.jsx
│   │   └── LoginForm.jsx
│   ├── App.jsx
│   ├── main.jsx
│   └── styles.css
├── .gitignore
├── index.html
├── package.json
└── README.md
```
