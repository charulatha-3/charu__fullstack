import { useState } from 'react';

function StudentMarks({ name, subject }) {
  const [marks, setMarks] = useState(50);

  const increaseMarks = () => {
    setMarks((currentMarks) => Math.min(currentMarks + 5, 100));
  };

  const decreaseMarks = () => {
    setMarks((currentMarks) => Math.max(currentMarks - 5, 0));
  };

  return (
    <div className="card marks-card">
      <div className="card-icon">📚</div>
      <h3>Student Marks</h3>

      <div className="marks-info">
        <p><span>Student Name</span><strong>{name}</strong></p>
        <p><span>Subject</span><strong>{subject}</strong></p>
      </div>

      <div className="marks-display">
        <span>Marks</span>
        <strong>{marks}</strong>
        <small>/ 100</small>
      </div>

      <div className="button-row">
        <button className="primary-btn" onClick={increaseMarks}>
          Increase Marks
        </button>
        <button className="secondary-btn" onClick={decreaseMarks}>
          Decrease Marks
        </button>
      </div>
    </div>
  );
}

export default StudentMarks;